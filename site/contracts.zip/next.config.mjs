/** @type {import('next').NextConfig} */
const nextConfig = {
      images: {
    domains: ["gateway.pinata.cloud"],
    formats: ["image/avif", "image/webp"],
  },
};

export default nextConfig;
